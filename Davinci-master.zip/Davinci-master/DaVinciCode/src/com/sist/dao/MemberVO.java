package com.sist.dao;

public class MemberVO {
	private String id;
	private String pwd;
	private String avaName;
	private String img;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getAvaName() {
		return avaName;
	}
	public void setAvaName(String avaName) {
		this.avaName = avaName;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}


}
